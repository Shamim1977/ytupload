﻿Imports Microsoft.VisualBasic

 Public Class Snippet
    Public Property title As String
    Public Property description As String
    Public Property tags As String()
    Public Property categoryId As String
End Class

Public Class Status
    Public Property privacyStatus As String
    Public Property embeddable As Boolean
    Public Property license As String
End Class

Public Class ytuploadobjects
    Public Property snippet As Snippet
    Public Property status As Status
End Class
