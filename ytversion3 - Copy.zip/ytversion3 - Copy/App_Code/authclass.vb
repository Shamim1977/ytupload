﻿Imports Microsoft.VisualBasic

Public Class authclass
    Public Property access_token() As String
        Get
            Return m_access_token
        End Get
        Set(value As String)
            m_access_token = Value
        End Set
    End Property
    Private m_access_token As String
    Public Property token_type() As String
        Get
            Return m_token_type
        End Get
        Set(value As String)
            m_token_type = Value
        End Set
    End Property
    Private m_token_type As String
    Public Property expires_in() As Integer
        Get
            Return m_expires_in
        End Get
        Set(value As Integer)
            m_expires_in = Value
        End Set
    End Property
    Private m_expires_in As Integer
    Public Property refresh_token() As String
        Get
            Return m_refresh_token
        End Get
        Set(value As String)
            m_refresh_token = Value
        End Set
    End Property
    Private m_refresh_token As String

    End Class
