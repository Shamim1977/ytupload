﻿Imports System.Net
Imports System.Web.Script.Serialization
Imports System.IO

Partial Class Default2
    Inherits System.Web.UI.Page
    Public myytuploadobject As New ytuploadobjects()

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Response.Write(CType(Session("access_token"), String))
        GetLocationForUpload()
        UploadVideoBytesToLocation()

    End Sub

    Public Sub GetLocationForUpload()
        Dim access_token As String = CType(Session("access_token"), String)
        Dim urltopost As String = "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status,contentDetails"
        Dim bodybytearray As Byte() = System.Text.Encoding.UTF8.GetBytes(SerializeJson())


        Dim myRequest As HttpWebRequest = HttpWebRequest.Create(urltopost)
        myRequest.Method = "POST"
        myRequest.ContentType = "application/json; charset=UTF-8"
        myRequest.Headers.Add(String.Format("Authorization: Bearer {0}", CType(Session("access_token"), String)))
        'following value for x-upload-content-length has been hardcoded. It should come from code. It is the value of data
        'you are sending.
        myRequest.Headers.Add("X-Upload-Content-Length", "3000000")
        myRequest.Headers.Add("X-Upload-Content-Type", "application/octet-stream")

        myRequest.ContentLength = bodybytearray.Length

        Dim datastream As Stream = myRequest.GetRequestStream()
        datastream.Write(bodybytearray, 0, bodybytearray.Length)
        datastream.Close()

        Dim myresponse As HttpWebResponse = myRequest.GetResponse()
        Dim myresponsedata As Stream = myresponse.GetResponseStream()

        Dim myreader As New StreamReader(myresponsedata)
        Dim responsefromserver As String = myreader.ReadToEnd()
        Session("location") = myresponse.Headers.Get("Location")


        myreader.Close()
        myresponsedata.Close()
        myresponse.Close()







    End Sub

    Public Function SerializeJson() As String
        Dim mySnippetResource As New Snippet()
        mySnippetResource.title = "This is test video title"
        mySnippetResource.description = "This is test description of test video"
        mySnippetResource.tags = {"test video", "aspnet", "ytuploads"}
        mySnippetResource.categoryId = "22"

        Dim myStatusSnippet As New Status()
        myStatusSnippet.privacyStatus = "unlisted"
        myStatusSnippet.embeddable = True
        myStatusSnippet.license = "youtube"

        myytuploadobject.snippet = mySnippetResource
        myytuploadobject.status = myStatusSnippet

        Dim mySerializer As New JavaScriptSerializer()
        Return mySerializer.Serialize(myytuploadobject)


    End Function

    Public Sub UploadVideoBytesToLocation()
        Dim location As String = CType(Session("location"), String)
        Dim pathoffiletoupload As String = IO.Path.GetFullPath(Server.MapPath("~/testvideo/small.mp4"))
        Dim readFilebytes As Byte() = IO.File.ReadAllBytes(pathoffiletoupload)
      
        Dim myRequest As HttpWebRequest = HttpWebRequest.Create(location)
        myRequest.Method = "PUT"
        myRequest.ContentType = "application/octet-stream"
        myRequest.Headers.Add(String.Format("Authorization: Bearer {0}", CType(Session("access_token"), String)))

        myRequest.Headers.Add("X-Upload-Content-Type", "application/octet-stream")

        myRequest.ContentLength = readFilebytes.Length

        Dim datastream As Stream = myRequest.GetRequestStream()
        datastream.Write(readFilebytes, 0, readFilebytes.Length)
        datastream.Close()

        'To check response refer to documentation. I will work on this part later and upload it when i get a chance
        'Basically to check the response, what you need to do is:
        'Send a request to another URL
        'In response, you get whether the upload was successful or not
        'This process is listed on the following URL
        'https://developers.google.com/youtube/v3/guides/using_resumable_upload_protocol

    End Sub
End Class
