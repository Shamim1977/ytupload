﻿Imports System.Net
Imports System.IO
Imports System.Runtime.Serialization.Json

Partial Class _Default
    Inherits System.Web.UI.Page

    'README YOUTUBE DOC
    'https://developers.google.com/youtube/v3/guides/using_resumable_upload_protocol


    'Enter ClientID for ytclientid variable
    Dim ytclientid As String = ""

    'Enter redirecturi which you entered in google developer console
    Dim redirecturi As String = "http://localhost:55453/Default.aspx"

    'Do not change the scope,responsetype,accesstype,authserverurl below
    Dim scope As String = "https://www.googleapis.com/auth/youtube"
    Dim responsetype As String = "code"
    Dim accesstype As String = "offline"
    Dim authserverurl As String = "https://accounts.google.com/o/oauth2/auth?"

    'Enter client secret for variable clientsecret below
    Dim clientsecret As String = ""

    Public myAuthClass As authclass


    Public Function GetUrl() As String
        Dim mysb As New StringBuilder()
        mysb.Append(authserverurl)
        mysb.AppendFormat("client_id={0}", ytclientid)
        mysb.AppendFormat("&redirect_uri={0}", Server.UrlEncode(redirecturi))
        mysb.AppendFormat("&scope={0}", Server.UrlEncode(scope))
        mysb.AppendFormat("&response_type={0}", responsetype)
        mysb.AppendFormat("&access_type={0}", accesstype)
        Return mysb.ToString()
    End Function

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
       
        If Request.QueryString("access_token") <> "" Then
            Session("access_token") = Request.QueryString("access_token").ToString()
        End If

        Dim authqs As NameValueCollection = HttpUtility.ParseQueryString(Request.QueryString.ToString())
        If (authqs.HasKeys) Then
            For Each mykey As String In authqs
                Dim key As String = mykey
                Dim value As String = authqs(mykey)
                Session("temporary_code") = value
            Next
            If Request.QueryString("code") <> "" Then
                ExchangeCodeForToken(CType(Session("temporary_code"), String))

            End If


        End If
    End Sub

    Public Sub ExchangeCodeForToken(ByVal code As String)
        'The token that would be returned as part of this sub should then be stored in a persistent storage. 
        'The httpresponse returns additional parameters which are expires and refresh token. Refresh token must be used to refresh the token when the token expires. 
        'In this code sample, I have not worked with token refresh. However, you can read the documentation and implement it.

        Dim url As String = "https://accounts.google.com/o/oauth2/token"
        Dim bodyparameters As String = String.Format("code={0}&client_id={1}&client_secret={2}&redirect_uri={3}&grant_type={4}", code, ytclientid, clientsecret, redirecturi, "authorization_code")
        Dim bytearray As Byte() = System.Text.Encoding.UTF8.GetBytes(bodyparameters)

        Dim myRequest As HttpWebRequest = HttpWebRequest.Create(url)
        myRequest.Method = "POST"
        myRequest.ContentType = "application/x-www-form-urlencoded"
        myRequest.ContentLength = bytearray.Length

        Dim dataStream As Stream = myRequest.GetRequestStream()
        dataStream.Write(bytearray, 0, bytearray.Length)

        dataStream.Close()
        Dim myresponse As HttpWebResponse = myRequest.GetResponse()
        Dim responsedata As Stream = myresponse.GetResponseStream()
        Dim myreader As New StreamReader(responsedata)
        Dim responsefromserver As String = myreader.ReadToEnd()

        DeSerializeAuthJson(responsefromserver)

        myreader.Close()
        responsedata.Close()
        myresponse.Close()

        Response.Redirect("~/Default2.aspx")


    End Sub

    Public Sub DeSerializeAuthJson(ByVal jsonstring As String)

        Dim myDeserializer As New Script.Serialization.JavaScriptSerializer()
        myAuthClass = myDeserializer.Deserialize(Of authclass)(jsonstring)
        Session("access_token") = myAuthClass.access_token

    End Sub
End Class
